#!/bin/bash

if [ "$1" = "-help" ]; then
	echo "Uso: $0 origen -d destino"
	exit 0
fi


if [ "$#" -ne 3 ] || [ "$2" != "-d" ]; then
	echo "Argumentos incorrectos. Utiliza el comando -help."
	exit 1
fi


origen="$1"
destino="$3"

if [ ! -d "$origen" ] || [ ! -d "$destino" ]; then
	echo "El origen o destino no existe."
	exit 1
fi


df "$origen" > /dev/null || exit 1
mount | grep " on $destino " > /dev/null || exit 1

if [ "$origen" = "/www_dir" ]; then
	mount|grep "on /www_dir" > /dev/null || exit 1
fi


nombre=$(basename "$origen")
fecha=$(date +%Y%m%d)

tar -czf "$destino/${nombre}_bpk_$fecha.tar·gz" "$origen"

# Este script hace backups de /var/log o /www_dir, recibe el origen y el destino con -d, y los comprueba
# si estan disponibles crea un archivo .tar.gz con la fecha (me apoye un poco en gemini para realizarlo).


