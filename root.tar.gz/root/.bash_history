history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
vi /etc/hostname
apt update
apds
apt upgrade
apt autoremove
cat /etc/network/interfaces
vi  /etc/apt/sources.list
vi /etc/apt/source.list
vi /etc/apt/sources.list
reboot
mkdir -p /www_dir /backup_dir
mount /dev/sdc /www_dir
mount /dev/sdc1/ www_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
cp /etc/fstab /etc/fstab.bak
nano /etc/fstab
vi /etc/fstab
mount -a
df -h
cat /proc/partitions > /opt/particion
cp /root/index.php /www_dir/
cp /root/logo.png /www_dir/
chmod 755 /www_dir
chmod 644 /www_dir/index.php /www_dir/logo.png
vi /etc/apache2/sites-available/000-default.conf
vi /etc/apache2/apache2.conf
apache2ctl configtest
systemctl restart apache2
ip route
cp /etc/network/interfaces /etc/network/interfaces.bak
vi /etc/network/interfaces
systemctl restart networking
ip a
ip route
systemctl restart networking
ip a
ip route
mkdir -p /opt/scripts
vi /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /www_dir -d /backup_dir
ls -lj /backup_dir
ls -lh /backup_dir
vi  /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log -d /backup_dir
ls -lh /backup_dir
crontab -e
crontab -l
systemctl status cron
ip a
ip route
ping -c 4 192.168.80.1
reboot
