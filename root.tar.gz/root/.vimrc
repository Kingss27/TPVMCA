set number
syntax on
